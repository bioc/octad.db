## ----eval=TRUE----------------------------------------------------------------
#select data
suppressMessages(library(octad.db))
phenoDF=.eh[["EH7274"]] #load data.frame with samples included in the OCTAD database. 
head(phenoDF) #list all data included within the package

## ----eval=TRUE----------------------------------------------------------------
res=data("res_example",package='octad.db') #load example res from octad.db
sRGES=data("sRGES_example",package='octad.db') #load example sRGES from octad.db

## ----eval=TRUE----------------------------------------------------------------
sessionInfo()

