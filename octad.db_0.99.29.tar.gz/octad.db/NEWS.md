# octad.db 0.99.22

* Added a `NEWS.md` file to track changes to the package.

# octad.db 0.99.23

* Submitted to Bioconductor
